export class Admin {
    id:number;
    username:string;
    password:string;
}
