import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposedTrainingsComponent } from './proposed-trainings.component';

describe('ProposedTrainingsComponent', () => {
  let component: ProposedTrainingsComponent;
  let fixture: ComponentFixture<ProposedTrainingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposedTrainingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposedTrainingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
