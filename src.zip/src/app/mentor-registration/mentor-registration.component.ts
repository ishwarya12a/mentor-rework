import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentor-registration',
  templateUrl: './mentor-registration.component.html',
  styleUrls: ['./mentor-registration.component.css']
})
export class MentorRegistrationComponent implements OnInit {
 
  mentor:Mentor=new Mentor();
  submitted=false;
  constructor(private mentorService:MentorService) { }

  ngOnInit() {
  }

 newUser():void{
   this.submitted=false;
   this.mentor=new Mentor();
 }

 save(){
  console.log("save mentor")
   this.mentorService.createMentor(this.mentor)
       .subscribe((data:Mentor)=>{console.log(data),error =>console.log(error)});
   this.mentor=new Mentor();
 }

 onSubmit(){
   console.log("submit mentor")
   this.submitted=true;
   this.save();
 }

}
