import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent implements OnInit {
 user:User=new User();
 submitted=false;
  constructor(private userService:UserService) { }

  ngOnInit() {
  }

 newUser():void{
   this.submitted=false;
   this.user=new User();
 }

 save(){
  console.log("save")
   this.userService.createUser(this.user)
       .subscribe((data:User)=>{console.log(data),error =>console.log(error)});
   this.user=new User();
 }

 onSubmit(){
   console.log("submit")
   this.submitted=true;
   this.save();
 }
}
