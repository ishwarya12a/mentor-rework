import { Component, OnInit } from '@angular/core';
import { TechnologiesService } from '../technologies.service';
import { Observable } from 'rxjs';
import { Trainings } from '../trainings';

@Component({
  selector: 'app-completed-trainings',
  templateUrl: './completed-trainings.component.html',
  styleUrls: ['./completed-trainings.component.css']
})
export class CompletedTrainingsComponent implements OnInit {
  trainings1:Observable<Trainings[]>
  username:string=window.localStorage.getItem("user");
  constructor(private technologiesService:TechnologiesService) { }

  ngOnInit() {
    this.trainings1=this.technologiesService.getAllTrainings(this.username);
  }

}
