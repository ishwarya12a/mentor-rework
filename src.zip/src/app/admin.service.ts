import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Admin } from './admin';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
 
  private baseUrl='http://localhost:9085/api5';
  constructor(private http:HttpClient) { }


  AdminDetails(username: string, password: string):Observable<Admin> {
    return this.http.get<Admin>(`${this.baseUrl}/checkAdmin/${username}/${password}`);
  }


}
