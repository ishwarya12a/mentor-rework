import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Mentor } from './mentor';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class MentorService {

  private baseUrl='http://localhost:9085/api4';
  constructor(private http:HttpClient) { }

  createMentor(mentor:Mentor):Observable<Mentor>{
    return this.http.post<Mentor>(`${this.baseUrl}/create`,mentor);
  }
  
  getMentor(username:string,password:string):Observable<Mentor>{
    return this.http.get<Mentor>(`${this.baseUrl}/checkMentor/${username}/${password}`);
  }

  getMentorProfile(username:String):Observable<Mentor>{
    console.log(username)
    return this.http.get<Mentor>(`${this.baseUrl}/getMentorProfile/${username}`);
  }
}
